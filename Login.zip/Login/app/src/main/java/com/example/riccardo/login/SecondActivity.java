package com.example.riccardo.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.jar.Attributes;

public class SecondActivity extends AppCompatActivity {

    private Button Back;
    private TextView Message;
    private Bundle extras;
    private String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Back = (Button) findViewById(R.id.btnBack);
        Message = (TextView) findViewById(R.id.tvMessage);
        Bundle extras = getIntent().getExtras();
        if(extras!=null) {
            String value = extras.getString("key");
            Message.setText("Benvenuto, " + String.valueOf(value) + ".");
        }else{
            Message.setText("Accesso negato.");
        }
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
