package com.example.riccardo.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Name = null;
    private EditText Password = null;
    private Button Login;
    private TextView Registrati;
    private TextView Errore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText) findViewById(R.id.etName);
        Password = (EditText) findViewById(R.id.etPassword);
        Login = (Button) findViewById(R.id.btnLogin);
        Registrati = (TextView) findViewById(R.id.tvRegister);
        Errore = (TextView) findViewById(R.id.tvError);

        Errore.setText("");
        Login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (TextUtils.isEmpty(Name.getText().toString()) && (TextUtils.isEmpty(Password.getText().toString()))) {
                    Errore.setText("Inserire le credenziali prima di continuare.");
                } else {
                    if (TextUtils.isEmpty(Name.getText().toString())) {
                        Errore.setText("Inserire un nome utente prima di continuare.");
                    } else {
                        if (TextUtils.isEmpty(Password.getText().toString())) {
                            Errore.setText("Inserire una password prima di continuare.");
                        } else {
                            validate(Name.getText().toString(), Password.getText().toString());
                        }
                    }
                }
            }
        });

        Registrati.setOnClickListener(new View.OnClickListener(){
            public void onClick (View view){
                Intent register = new Intent(MainActivity.this, FakeActivity.class);
                startActivity(register);
            }
        });
    }

    private void validate(String userName, String userPassword) {
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        if ((userName.equals("Admin")) && (userPassword.equals("Pass"))) {
            intent.putExtra("key", userName);
            startActivity(intent);
        } else {
            startActivity(intent);
        }
    }
}
